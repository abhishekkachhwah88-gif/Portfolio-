const API = "/api/leads";

document.getElementById("leadForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    await fetch(API, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
            name: name.value,
            email: email.value
        })
    });
    load();
});

async function load() {
    const res = await fetch(API);
    const data = await res.json();
    leadList.innerHTML = data.map(l => `<li>${l.name}</li>`).join("");
}

load();