# Portfolio Website

Simple portfolio using HTML, CSS, JavaScript.

## Run
Open index.html in browser.
