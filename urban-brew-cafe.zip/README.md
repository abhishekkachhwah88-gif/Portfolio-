# Urban Brew Café Website

## Project Description
This is a local business website created for a café.

## Features
- Responsive design
- Menu display
- Contact form

## Technologies Used
- HTML
- CSS
- JavaScript
